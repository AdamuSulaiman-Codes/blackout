BLACKOUT 1.0 (Windows x64)
-------------------------
1. Unzip the whole folder.
2. Run BLACKOUT.exe. Keep BLACKOUT.pck beside it.
3. If Windows SmartScreen warns, choose More info -> Run anyway.
Keyboard + mouse. W = jump / hold to fly. Esc = pause.
No installer. No network required.
